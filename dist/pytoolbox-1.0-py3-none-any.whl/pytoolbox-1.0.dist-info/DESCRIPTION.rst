pytoolbox: a simple Python utilities pool
=========================================

pytoolbox is a simple Python projects that aims to regroup some
utilities I often use in my other Python projects.
Project's homepage is at <https://github.com/Talw3g/pytoolbox>.

----

This project currently includes the following modules:

**colortxt**: offers a convenient way to customize text with color,
background and blink.

**confirm**: a wannabe "apt-like dialog" wrapper that asks for user's
choice in the infamous *[Y/n], [y/N]* way.


